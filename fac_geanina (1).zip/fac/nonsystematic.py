def build_polynomial_from_input(number):
    # Transformă șirul de intrare într-un polinom
    polynomial = [int(bit) for bit in number]
    return polynomial

def multiply_polynomials(polynomial1, polynomial2):
    # Inițializează rezultatul cu o listă de zerouri
    result = [0] * (len(polynomial1) + len(polynomial2) - 1)

    # Efectuează înmulțirea polinoamelor
    for i in range(len(polynomial1)):
        for j in range(len(polynomial2)):
            result[i + j] ^= polynomial1[i] & polynomial2[j]

    return result

def compute_nonsystematic(number):
    input_polynomial = build_polynomial_from_input(number)

    # Construiește polinomul (1 + x + x^2)
    multiplier_polynomial_u = [1, 1, 1]

    # Construiește polinomul (1 + x)
    multiplier_polynomial_w = [1, 1]

    # Efectuează înmulțirea cu u
    result_polynomial_u = multiply_polynomials(input_polynomial, multiplier_polynomial_u)

    # Efectuează înmulțirea cu w
    result_polynomial_w = multiply_polynomials(input_polynomial, multiplier_polynomial_w)

    # Converteste rezultatele în șiruri de cifre 0 și 1
    result_str_u = ''.join(map(str, result_polynomial_u))
    result_str_w = ''.join(map(str, result_polynomial_w))

    # Construiește șirul cerut cu alternarea dintre w și u
    output_str = ''
    for i in range(7):
        output_str += result_str_w[i] + result_str_u[i]

    return output_str
