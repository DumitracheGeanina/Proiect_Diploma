import sys
from PyQt5.QtWidgets import QLineEdit, QMainWindow,QHBoxLayout, QPushButton, QWidget, QTableWidgetItem, QApplication, QTableWidget,QVBoxLayout
from PyQt5.QtGui import QPalette,QColor,QKeySequence
from PyQt5.QtCore import Qt, QEvent

from systematic import compute_systematic
from nonsystematic import compute_nonsystematic

class OvalButton(QPushButton):
    def __init__(self, text, parent=None, background_color = "rgb(159, 176, 255)", color="#FFFFFF", width = 150, font_size=18):
        super().__init__(text, parent)
        # Set button properties to make it oval
        self.setFixedWidth(width)  # Adjust the width as needed
        self.setFixedHeight(75)  # Adjust the height as needed
        
        self.setAutoFillBackground(True)
        palette = self.palette()
        palette.setColor(QPalette.Button, QColor(255, 255, 255))  # Button background color
        palette.setColor(QPalette.ButtonText, QColor(0, 0, 0))  # Button text color
        self.setPalette(palette)
        style_sheet = (
            "QPushButton {"
            f"   background-color: {background_color};"  
            f"   color: {color};"             
            "   font-weight: bold;"         
            f"   font-size: {font_size}px;"           
            "   text-transform: uppercase;" #
            "   border-radius: 35px"
            "}"
        )

        # Apply the style sheet to the button
        self.setStyleSheet(style_sheet)
        


class RoundButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setFixedWidth(300) 
        self.setFixedHeight(200) 
        
        self.setAutoFillBackground(True)
        palette = self.palette()
        palette.setColor(QPalette.Button, QColor(255, 255, 255)) 
        palette.setColor(QPalette.ButtonText, QColor(0, 0, 0)) 
        self.setPalette(palette)
        style_sheet = (
            "QPushButton {"
            "   background-color: #000000;"  
            "   color: #FFFFFF;"             
            "   font-weight: bold;"        
            "   font-size: 18px;"           
            "   text-transform: uppercase;" 
            "   border-radius: 100px"
            "}"
        )

        self.setStyleSheet(style_sheet)

class BinaryLineEdit(QLineEdit):
    def __init__(self, parent=None, max_length = 7):
        super().__init__(parent)
        self.setMaxLength(max_length)
        self.textChanged.connect(self.validate_input)

    def validate_input(self, text):
        # Remove any characters that are not '0' or '1'
        validated_text = ''.join(char for char in text if char in ('0', '1'))

        # Set the validated text to the line edit
        self.setText(validated_text)

class CustomNonSystematicTableWidget(QTableWidget):
    def __init__(self, rows, columns, parent=None):
        super().__init__(rows, columns, parent)
        self.setContentsMargins(0, 0, 0, 0)
    
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Delete):
            for item in self.selectedItems():
                item.setText("")  # Șterge textul din celula selectată
        else:
            super().keyPressEvent(event)

    def update_column_c1(self):
        for row in range(self.rowCount()):
            value = self.item(row, 1).text() if self.item(row, 1) else ""
            self.setItem(row, 2, QTableWidgetItem(value))

    def update_column_c2(self):
        self.setItem(0, 3, QTableWidgetItem("0"))
        for row in range(1, self.rowCount()):
            previous_value = self.item(row - 1, 2).text() if self.item(row - 1, 2) else ""
            self.setItem(row, 3, QTableWidgetItem(previous_value))

    def calculate_u1(self):
        for row in range(self.rowCount()):
            val_i = int(self.item(row, 1).text()) if self.item(row, 1) and self.item(row, 1).text().isdigit() else 0
            val_c1 = int(self.item(row - 1, 2).text()) if row > 0 and self.item(row - 1, 2) and self.item(row - 1, 2).text().isdigit() else 0

            xor_result = val_i ^ val_c1
            self.setItem(row, 4, QTableWidgetItem(str(xor_result)))

    def calculate_u2(self):
        for row in range(self.rowCount()):
            val_i = int(self.item(row, 1).text()) if self.item(row, 1) and self.item(row, 1).text().isdigit() else 0
            val_c1 = int(self.item(row - 1, 2).text()) if row > 0 and self.item(row - 1, 2) and self.item(row - 1, 2).text().isdigit() else 0
            val_c2 = int(self.item(row - 1, 3).text()) if row > 0 and self.item(row - 1, 3) and self.item(row - 1, 3).text().isdigit() else 0

            xor_result = val_i ^ val_c1 ^ val_c2
            self.setItem(row, 5, QTableWidgetItem(str(xor_result)))

    def on_header_clicked(self, section):
        if section == 2:  # C1 header clicked
            self.update_column_c1()
        elif section == 3:  # C2 header clicked
            self.update_column_c2()
        elif section == 4:  # u1 header clicked
            self.calculate_u1()
        elif section == 5:  # u2 header clicked
            self.calculate_u2()


class CustomSystematicTableWidget(QTableWidget):
    def __init__(self, rows, columns, parent=None):
        super().__init__(rows, columns, parent)
        self.setContentsMargins(0, 0, 0, 0)

    
    def keyPressEvent(self, event):
        if event.matches(QKeySequence.Delete):
            for item in self.selectedItems():
                item.setText("")  # Șterge textul din celula selectată
        else:
            super().keyPressEvent(event)

    def update_column_c1(self):
        for row in range(self.rowCount()):
            value = self.item(row, 1).text() if self.item(row, 1) else ""
            self.setItem(row, 2, QTableWidgetItem(value))

    def update_column_c2(self):
        self.setItem(0, 3, QTableWidgetItem("0"))
        for row in range(1, self.rowCount()):
            previous_value = self.item(row - 1, 2).text() if self.item(row - 1, 2) else ""
            self.setItem(row, 3, QTableWidgetItem(previous_value))

    def copy_column_i_to_i_prime(self):
        for row in range(self.rowCount()):
            value = self.item(row, 1).text() if self.item(row, 1) else ""
            self.setItem(row, 4, QTableWidgetItem(value))

    def calculate_xor(self):
        for row in range(self.rowCount()):
            val_i = int(self.item(row, 1).text()) if self.item(row, 1) and self.item(row, 1).text().isdigit() else 0
            val_c1 = int(self.item(row - 1, 2).text()) if row > 0 and self.item(row - 1, 2) and self.item(row - 1, 2).text().isdigit() else 0
            val_c2 = int(self.item(row - 1, 3).text()) if row > 0 and self.item(row - 1, 3) and self.item(row - 1, 3).text().isdigit() else 0

            xor_result = val_i ^ val_c1 ^ val_c2
            self.setItem(row, 5, QTableWidgetItem(str(xor_result)))

    def on_header_clicked(self, section):
        if section == 2:  # C1 header clicked
            self.update_column_c1()
        elif section == 3:  # C2 header clicked
            self.update_column_c2()
        elif section == 4:  # i' header clicked
            self.copy_column_i_to_i_prime()
        elif section == 5:  # v header clicked
            self.calculate_xor()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Circle Shape Over Background")
        self.setGeometry(100, 100, 1152, 648)
        self.pageNo = 0
        self.language = None
        self.left_button = None
        self.right_button = None
        self.compute_option = None
        self.result = None

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.background_image_path = f"images/{self.pageNo}.png"    
        # Set the background image using style sheets
        self.central_widget.setStyleSheet(f"background-image: url({self.background_image_path}); background-attachment: fixed;")
    
        self.layout = QHBoxLayout(self.central_widget)
        self.left_button = OvalButton("Incepe", self)
        self.left_button.clicked.connect(self.left_button_clicked)
        self.left_button.move(250,400)
        self.left_button.setFocusPolicy(Qt.NoFocus)

        self.right_button = OvalButton("Begin", self)
        self.right_button.clicked.connect(self.right_button_clicked)
        self.right_button.move(750,400)
        self.right_button.setFocusPolicy(Qt.NoFocus)

        self.history_button = OvalButton("Istoric", self, background_color="transparent", color="black", width=220, font_size=30)
        self.history_button.clicked.connect(self.history_button_clicked)
        self.history_button.move(470,100)
        self.history_button.setFocusPolicy(Qt.NoFocus)
        self.history_button.hide()

        self.theoretical_aspects_button = OvalButton("Aspecte teoretice", self, background_color="transparent", color="black", width=360, font_size=30)
        self.theoretical_aspects_button.clicked.connect(self.theoretical_aspects_button_clicked)
        self.theoretical_aspects_button.move(420, 230)
        self.theoretical_aspects_button.setFocusPolicy(Qt.NoFocus)
        self.theoretical_aspects_button.hide()

        self.lab_work_button = OvalButton("Lucrare de laborator", self, background_color="transparent", color="black", width=400, font_size=30)
        self.lab_work_button.clicked.connect(self.lab_work_button_clicked)
        self.lab_work_button.move(390, 410)
        self.lab_work_button.setFocusPolicy(Qt.NoFocus)
        self.lab_work_button.hide()

        self.systematic_button = RoundButton("", self)
        self.systematic_button.clicked.connect(self.systematic_button_clicked)
        self.systematic_button.move(170,300)
        self.systematic_button.setFocusPolicy(Qt.NoFocus)

        self.nonsystematic_button = RoundButton("", self)
        self.nonsystematic_button.clicked.connect(self.nonsystematic_button_clicked)
        self.nonsystematic_button.move(670,300)
        self.nonsystematic_button.setFocusPolicy(Qt.NoFocus)

        self.hidesystNonsysButtons()

        self.result_button = OvalButton(self.result, self, color="#000000", width=250)
        self.result_button.move(470,155)
        self.result_button.setFocusPolicy(Qt.NoFocus)
        self.result_button.hide()

        self.input_field = BinaryLineEdit(self)
        self.input_field.setPlaceholderText("Enter 7 digits number")
        style_sheet = (
            "QLineEdit {"
            "   border: 2px solid #333;"    
            "   border-radius: 10px;"        
            "   padding: 10px 15px;"            
            "   font-size: 16px;"               
            "   background-color: #FFFFFF;"
            "}"
        )

        self.viterbi_input_field = BinaryLineEdit(self, max_length=6)
        self.viterbi_input_field.setPlaceholderText("Enter 6 digits number")
        style_sheet = (
            "QLineEdit {"
            "   border: 2px solid #333;"    
            "   border-radius: 10px;"        
            "   padding: 10px 15px;"            
            "   font-size: 16px;"               
            "   background-color: #FFFFFF;"
            "}"
        )

        self.viterbi_r_estimate = OvalButton("", self, color="#000000", width=150)
        self.viterbi_r_estimate.move(520,250)
        self.viterbi_r_estimate.setFocusPolicy(Qt.NoFocus)
        self.viterbi_r_estimate.hide()

        self.viterbi_i_estimate = OvalButton("100", self, color="#000000", width=150)
        self.viterbi_i_estimate.move(520,400)
        self.viterbi_i_estimate.setFocusPolicy(Qt.NoFocus)
        self.viterbi_i_estimate.hide()

    
        self.input_field.setStyleSheet(style_sheet)
        self.input_field.setMinimumSize(150, 40)  
        self.input_field.setFocusPolicy(Qt.StrongFocus)
        self.input_field.move(525, 55)
        self.input_field.hide()
        self.input_field.setMaxLength(7)
        self.input_field.returnPressed.connect(self.handle_input_enter_key)

        self.viterbi_input_field.setStyleSheet(style_sheet)
        self.viterbi_input_field.setMinimumSize(150, 50)  
        self.viterbi_input_field.setFocusPolicy(Qt.StrongFocus)
        self.viterbi_input_field.move(525, 70)
        self.viterbi_input_field.hide()
        self.viterbi_input_field.returnPressed.connect(self.handle_viterbi_input_enter_key)

        self.systematic_table = CustomSystematicTableWidget(7, 6)
        self.systematic_table.setHorizontalHeaderLabels(['T', 'i', 'C1', 'C2', "i'", 'c'])

        for i in range(7):
            self.systematic_table.setItem(i, 0, QTableWidgetItem(str(i + 1)))

        # Setează valoarea inițială pentru coloanele 'C1' și 'C2'
        self.systematic_table.setItem(0, 2, QTableWidgetItem(""))
        self.systematic_table.setItem(0, 3, QTableWidgetItem("0"))

        # Conectarea click-ului pe header la sloturile corespunzătoare
        self.systematic_header = self.systematic_table.horizontalHeader()
        self.systematic_header.sectionClicked.connect(self.systematic_table.on_header_clicked)
        self.systematic_table.hide()

        self.nonsystematic_table = CustomNonSystematicTableWidget(7, 6)
        self.nonsystematic_table.setHorizontalHeaderLabels(['T', 'i', 'C1', 'C2', 'u1', 'u2'])

        # Numerotarea liniilor pentru coloana 'T'
        for i in range(7):
            self.nonsystematic_table.setItem(i, 0, QTableWidgetItem(str(i + 1)))

        # Setează valoarea inițială pentru coloanele 'C1' și 'C2'
        self.nonsystematic_table.setItem(0, 2, QTableWidgetItem(""))
        self.nonsystematic_table.setItem(0, 3, QTableWidgetItem("0"))

        # Conectarea click-ului pe header la sloturile corespunzătoare
        self.non_systematic_header = self.nonsystematic_table.horizontalHeader()
        self.non_systematic_header.sectionClicked.connect(self.nonsystematic_table.on_header_clicked)
        self.nonsystematic_table.hide()

        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.addWidget(self.systematic_table)
        self.layout.addWidget(self.nonsystematic_table)
        self.central_widget.installEventFilter(self)
      

    def left_button_clicked(self):
        self.hideLeftRightButtons()
        self.language = "ro"
        self.pageNo = 1
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()
        self.systematic_button.setText("Varianta sistematica")
        self.nonsystematic_button.setText("Varianta nesistematica")
        self.history_button.setText("Istoric")
        self.theoretical_aspects_button.setText("Aspecte teoretice")
        self.lab_work_button.setText("Lucrare de laborator")
        
        

    def right_button_clicked(self):
        self.hideLeftRightButtons()
        self.language = "en"
        self.pageNo = 1
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()
        self.systematic_button.setText("Systematic option")
        self.nonsystematic_button.setText("Non-systematic option")
        self.history_button.setText("History")
        self.theoretical_aspects_button.setText("Theoretical aspects")
        self.lab_work_button.setText("Laboratory work")

    def history_button_clicked(self):
        self.pageNo = 3
        self.hideGoToButtons()
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()
    
    def theoretical_aspects_button_clicked(self):
        self.pageNo = 4
        self.hideGoToButtons()
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()

    def lab_work_button_clicked(self):
        self.pageNo = 5
        self.hideGoToButtons()
        self.showSystNonsysButtons()
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()

    def systematic_button_clicked(self):
        self.hidesystNonsysButtons()
        self.compute_option = "systematic"
        self.pageNo = 6
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()
        self.viterbi_r_estimate.setText("110111")

    def nonsystematic_button_clicked(self):
        self.hidesystNonsysButtons()
        self.compute_option = "nonsystematic"
        self.pageNo = 6
        self.background_image_path = self.set_background_image_path()
        self.update_background_image()
        self.viterbi_r_estimate.setText("111101")

    def addLeftRightButtons(self):
        self.left_button = OvalButton("Left Button", self)
        self.left_button.clicked.connect(self.left_button_clicked)
        self.left_button.move(250,400)

        self.right_button = OvalButton("Right Button", self)
        self.right_button.clicked.connect(self.left_button_clicked)
        self.right_button.move(750,400)

    def hideLeftRightButtons(self):
        self.left_button.hide()
        self.right_button.hide()

    def showLeftRightButtons(self):
        self.left_button.show()
        self.right_button.show()

    def hideGoToButtons(self):
        self.history_button.hide()
        self.theoretical_aspects_button.hide()
        self.lab_work_button.hide()

    def showGoToButtons(self):
        self.history_button.show()
        self.theoretical_aspects_button.show()
        self.lab_work_button.show()

    def hidesystNonsysButtons(self):
        self.systematic_button.hide()
        self.nonsystematic_button.hide()

    def showSystNonsysButtons(self):
        self.systematic_button.show()
        self.nonsystematic_button.show()

    def keyPressEvent(self, event):
        if self.pageNo == 1:
            if event.key() == Qt.Key_Space:
                self.pageNo = self.pageNo + 1
                self.background_image_path = self.set_background_image_path()
                self.update_background_image()
                self.showGoToButtons()
        
        if event.key() == Qt.Key_Escape and self.pageNo !=7:
            self.compute_option = None
            self.pageNo = 0
            self.language = ""
            self.background_image_path = self.set_background_image_path()
            self.update_background_image()
            self.showLeftRightButtons()
            self.hideGoToButtons()
            self.hidesystNonsysButtons()
            self.input_field.clearFocus()
            self.input_field.setText(None)
            self.viterbi_input_field.clearFocus()
            self.viterbi_input_field.hide()
            self.viterbi_input_field.setText(None)
            self.viterbi_i_estimate.hide()
            self.viterbi_i_estimate.setText(None)
            self.viterbi_r_estimate.hide()
            self.viterbi_r_estimate.setText(None)

        if event.key() == Qt.Key_Escape and self.pageNo ==7:
            self.input_field.clearFocus()
            self.systematic_table.hide()
            self.nonsystematic_table.hide()
       
        
        if self.pageNo >0 and self.pageNo <= 10 and self.pageNo != 1:
            if event.key() == Qt.Key.Key_Right and self.pageNo not in [2, 3, 4, 10] and self.pageNo != 5:
                self.pageNo = self.pageNo + 1
                self.background_image_path = self.set_background_image_path()
                self.update_background_image()
            if event.key() == Qt.Key.Key_Left and self.pageNo != 2 and self.pageNo != 0:
                if self.pageNo == 3 or self.pageNo == 4:
                    self.pageNo = 2
                elif self.pageNo == 5: 
                    self.pageNo = 2
                    self.hidesystNonsysButtons()
                elif self.pageNo == 6:
                    self.compute_option = None
                    self.showSystNonsysButtons()
                    self.pageNo = self.pageNo - 1
                elif self.pageNo == 10:
                    self.viterbi_input_field.hide()
                    self.viterbi_input_field.setText(None)
                    self.viterbi_r_estimate.hide()
                    self.viterbi_i_estimate.hide()
                    self.pageNo = self.pageNo - 1
                elif self.pageNo in [8, 9]:
                    self.pageNo = 7
                    if (self.compute_option == "systematic"):
                        self.systematic_table.hide()
                    elif (self.compute_option == "nonsystematic"):
                        self.nonsystematic_table.hide()
                else:
                    self.pageNo = self.pageNo - 1
                self.background_image_path = self.set_background_image_path()
                self.update_background_image()
                self.hideLeftRightButtons()

        
        if self.pageNo == 2:
            self.showGoToButtons()

        if self.pageNo != 7 and self.pageNo != 8:
            self.input_field.hide()
            if self.input_field.text() != "":
                self.input_field.setText("")

        if self.pageNo == 7:
            self.input_field.show()

        if self.pageNo != 8:
            self.result_button.hide()

        if self.pageNo < 8:
            self.result_button.setText("")

        if self.pageNo == 10 and event.key() == Qt.Key.Key_Right:
            self.viterbi_input_field.show()

        if self.pageNo == 9:
            if (self.compute_option == "systematic"):
                self.systematic_table.show()
            elif (self.compute_option == "nonsystematic"):
                self.nonsystematic_table.show()

        elif self.pageNo in [8, 10]:
            self.systematic_table.hide()
            self.nonsystematic_table.hide()

    
    def eventFilter(self, obj, event):
        if event.type() == QEvent.MouseButtonPress:
            global_pos = event.globalPos()

            local_pos = self.mapFromGlobal(global_pos)

            if not self.input_field.geometry().contains(local_pos):
                self.input_field.clearFocus()
                self.viterbi_input_field.clearFocus()

        return super().eventFilter(obj, event)

    def set_background_image_path(self):
        if self.compute_option != None:
            return f"images/{self.language}/{self.compute_option}/{self.pageNo}.png"
        return f"images/{self.language}/{self.pageNo}.png"


    def handle_input_enter_key(self):
        if(len(self.input_field.text()) == 7):
            self.input_field.clearFocus()
            if self.compute_option == "systematic":
                self.result = compute_systematic(self.input_field.text())
            if self.compute_option == "nonsystematic":
                self.result = compute_nonsystematic(self.input_field.text())
            self.pageNo = self.pageNo + 1
            self.background_image_path = self.update_background_image()
            self.result_button.setText(self.result)
            self.result_button.show()

    def handle_viterbi_input_enter_key(self):
        if(len(self.viterbi_r_estimate.text()) == 6):
            self.viterbi_r_estimate.clearFocus()
            self.viterbi_r_estimate.show()
            self.viterbi_i_estimate.show()

    def update_background_image(self):
        self.central_widget.setStyleSheet(f"background-image: url({self.set_background_image_path()}); background-attachment: fixed;")


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()