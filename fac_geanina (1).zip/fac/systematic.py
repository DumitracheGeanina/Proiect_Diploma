def build_polynomial_from_input(number):
    # Transformă șirul de intrare într-un polinom
    polynomial = [int(bit) for bit in number]
    return polynomial

def multiply_polynomials(polynomial1, polynomial2):
    # Inițializează rezultatul cu o listă de zerouri
    result = [0] * (len(polynomial1) + len(polynomial2) - 1)

    # Efectuează înmulțirea polinoamelor
    for i in range(len(polynomial1)):
        for j in range(len(polynomial2)):
            result[i + j] ^= polynomial1[i] & polynomial2[j]

    return result

def compute_systematic(number):
    input_polynomial = build_polynomial_from_input(number)
    # Construiește polinomul (1 + x + x^2)
    multiplier_polynomial = [1, 1, 1]

    # Efectuează înmulțirea
    result_polynomial = multiply_polynomials(input_polynomial, multiplier_polynomial)

    # Converteste rezultatul în șir de cifre 0 și 1
    result_str = ''.join(map(str, result_polynomial))

    # Construiește șirul cerut cu perechi de 2 cifre
    output_str = ''
    for i in range(7):
        output_str += number[i] + result_str[i]

    return output_str